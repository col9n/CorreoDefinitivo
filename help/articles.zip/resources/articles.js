function getArticles() {
  var articles = [  {"name": "first article","id": "first_article","category": "articles","url": "articles/article_firstarticulo.html"},
  {"name": "second article","id": "second_article","category": "articles","url": "articles/article_secondaarticulo.html"}]
  return articles;
}